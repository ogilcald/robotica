#include "MyQtimer.h"

MyQtimer::MyQtimer(): QThread()
{	
	value=1000;
}
	void MyQtimer::setValue(int n){
		m.lock();
		value=n;
		m.unlock();
	}
	
void MyQtimer::run(){
	while(1){
		m.lock();
		int aux=value;
		m.unlock();
	msleep(aux);
	emit mytimeout();
	}
	}

MyQtimer::~MyQtimer()
{
	
}

